from bampy.extensions.pandas.prompt_sub import PandasExtension

__all__ = ["PandasExtension"]
