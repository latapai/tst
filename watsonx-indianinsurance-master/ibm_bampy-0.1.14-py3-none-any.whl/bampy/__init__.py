import logging
import warnings

from bampy._version import __version__ as v
from bampy.credentials import Credentials
from bampy.metadata import Metadata
from bampy.model import Model
from bampy.prompt_pattern import PromptPattern

logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = ["Model", "Credentials", "Metadata", "PromptPattern"]

__version__ = v


warnings.warn(
    """
The bampy python library is now deprecated. \
Please visit the wiki page here: https://github.ibm.com/ai-foundation/bampy/wiki/Migrating-to-ibm-generative-ai \
for more details and instructrions on how to migrate to ibm-generative-ai.
""",
    DeprecationWarning,
    stacklevel=2,
)
