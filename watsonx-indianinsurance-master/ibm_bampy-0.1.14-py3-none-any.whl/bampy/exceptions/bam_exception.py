import logging
from typing import Union

from pydantic import ValidationError
from requests import Response

from bampy.schemas.responses import ErrorResponse

logger = logging.getLogger(__name__)


class BAMException(Exception):
    def __init__(self, error: Union[Exception, Response]) -> None:
        if isinstance(error, Response):
            try:
                self.error = ErrorResponse(**error.json())
                self.error_message = self.error.message
            except ValidationError:
                self.error = error
                self.error_message = str(error.content)
        else:
            self.error = error
            self.error_message = str(error)
        logger.error(self.error_message)
        super().__init__(self.error_message)
